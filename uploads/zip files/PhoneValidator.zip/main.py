import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
import requests
import os
import threading
import smtplib
from email.message import EmailMessage
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas


result_df = None

# ------------------ Spinner Control ------------------

def start_spinner():
    spinner_frame.pack(pady=(15, 5))
    spinner_label.config(text="Validating... Please wait ⏳")
    progress_spinner.start(10)

def stop_spinner():
    progress_spinner.stop()
    spinner_frame.pack_forget()
    spinner_label.config(text="")


def download_result_pdf():
    if result_df is not None:
        save_path = filedialog.asksaveasfilename(defaultextension=".pdf",
                                                 filetypes=[("PDF files", "*.pdf")])
        if save_path:
            try:
                c = canvas.Canvas(save_path, pagesize=letter)
                width, height = letter
                x_offset = 50
                y_offset = height - 50
                line_height = 20

                c.setFont("Helvetica-Bold", 14)
                c.drawString(x_offset, y_offset, "Phone Number Validation Results")
                y_offset -= line_height * 2

                c.setFont("Helvetica", 10)
                headers = ["Phone", "Valid", "Country", "Carrier"]
                for i, header in enumerate(headers):
                    c.drawString(x_offset + i * 130, y_offset, header)
                y_offset -= line_height

                for _, row in result_df.iterrows():
                    c.drawString(x_offset, y_offset, str(row["Phone"]))
                    c.drawString(x_offset + 130, y_offset, str(row["Valid"]))
                    c.drawString(x_offset + 260, y_offset, str(row["Country"]))
                    c.drawString(x_offset + 390, y_offset, str(row["Carrier"]))
                    y_offset -= line_height

                    if y_offset < 50:
                        c.showPage()
                        y_offset = height - 50
                        c.setFont("Helvetica", 10)

                c.save()
                messagebox.showinfo("Saved", f"PDF saved to:\n{save_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save PDF:\n{e}")
    else:
        messagebox.showerror("Error", "No data to save.")

# ------------------ Threaded Validation ------------------

def threaded_validate_numbers():
    threading.Thread(target=validate_numbers).start()

# ------------------ Backend Logic ------------------

def select_file():
    file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
    if file_path:
        entry_file_path.delete(0, tk.END)
        entry_file_path.insert(0, file_path)
def send_email_with_attachment():
    if result_df is None:
        messagebox.showerror("Error", "No result data to send.")
        return

    def send():
        sender_email = entry_sender.get().strip()
        app_password = entry_app_password.get().strip()
        recipient_email = entry_recipient.get().strip()

        if not sender_email or not app_password or not recipient_email:
            messagebox.showerror("Error", "Please fill all email fields.")
            return

        try:
            # Save result as temporary CSV
            temp_path = "result_temp.csv"
            result_df.to_csv(temp_path, index=False)

            msg = EmailMessage()
            msg['Subject'] = "Validated Phone Numbers"
            msg['From'] = sender_email
            msg['To'] = recipient_email
            msg.set_content("Please find the attached validated phone numbers.")

            # Read and attach file
            with open(temp_path, 'rb') as f:
                file_data = f.read()
                file_name = f.name
            msg.add_attachment(file_data, maintype='application', subtype='octet-stream', filename="validated_numbers.csv")

            # Send email
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
                smtp.login(sender_email, app_password)
                smtp.send_message(msg)

            os.remove(temp_path)
            messagebox.showinfo("Success", f"Email sent to {recipient_email}!")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to send email:\n{e}")

    # GUI popup for email details
    email_popup = tk.Toplevel(root)
    email_popup.title("Send Result via Email")
    email_popup.geometry("400x250")
    email_popup.configure(bg=BG_COLOR)

    tk.Label(email_popup, text="Sender Email (Gmail):", font=FONT, bg=BG_COLOR, fg=TEXT_COLOR).pack(pady=(10, 0))
    entry_sender = tk.Entry(email_popup, font=FONT, width=40, bg=INPUT_BG, fg=TEXT_COLOR)
    entry_sender.pack()

    tk.Label(email_popup, text="App Password:", font=FONT, bg=BG_COLOR, fg=TEXT_COLOR).pack(pady=(10, 0))
    entry_app_password = tk.Entry(email_popup, show="*", font=FONT, width=40, bg=INPUT_BG, fg=TEXT_COLOR)
    entry_app_password.pack()

    tk.Label(email_popup, text="Recipient Email:", font=FONT, bg=BG_COLOR, fg=TEXT_COLOR).pack(pady=(10, 0))
    entry_recipient = tk.Entry(email_popup, font=FONT, width=40, bg=INPUT_BG, fg=TEXT_COLOR)
    entry_recipient.pack()

    send_btn = ttk.Button(email_popup, text="Send Email", command=send)
    send_btn.pack(pady=20)

def validate_numbers():
    root.after(0, start_spinner)
    api_key = entry_api_key.get().strip()
    if not api_key:
        root.after(0, stop_spinner)
        messagebox.showerror("Error", "Please enter your Veriphone API key.")
        return

    file_path = entry_file_path.get()
    if not os.path.exists(file_path):
        root.after(0, stop_spinner)
        messagebox.showerror("Error", "Please select a valid CSV file.")
        return

    try:
        df = pd.read_csv(file_path)
    except Exception:
        root.after(0, stop_spinner)
        messagebox.showerror("Error", "Error reading the CSV file.")
        return

    if 'Phone' not in df.columns:
        root.after(0, stop_spinner)
        messagebox.showerror("Error", "CSV must have a column named 'Phone'.")
        return

    validated_data = []
    valid_count = invalid_count = error_count = 0

    for phone in df['Phone']:
        phone = str(phone).strip()
        if not phone.startswith('+'):
            phone = '+' + phone

        url = f"https://api.veriphone.io/v2/verify?phone={phone}&key={api_key}"
        try:
            response = requests.get(url)
            data = response.json()
            valid = data.get("phone_valid", False)
            country = data.get("country", "Unknown")
            carrier = data.get("carrier") or "Unavailable"

            validated_data.append({
                "Phone": phone,
                "Valid": valid,
                "Country": country,
                "Carrier": carrier
            })

            if valid: valid_count += 1
            else: invalid_count += 1

        except Exception:
            validated_data.append({
                "Phone": phone,
                "Valid": "Error",
                "Country": "Error",
                "Carrier": "Error"
            })
            error_count += 1

    global result_df
    result_df = pd.DataFrame(validated_data)

    def update_ui():
        # Clear previous results
        for row in tree.get_children():
            tree.delete(row)

        # Insert new results
        for row in validated_data:
            tree.insert('', tk.END, values=(row["Phone"], row["Valid"], row["Country"], row["Carrier"]))
        stop_spinner()
        messagebox.showinfo("Validation Complete", f"Valid: {valid_count} | Invalid: {invalid_count} | Errors: {error_count}")

    root.after(0, update_ui)

# ------------------ File Download Handlers ------------------

def download_result():
    if result_df is not None:
        save_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if save_path:
            result_df.to_csv(save_path, index=False)
            messagebox.showinfo("Saved", f"File saved to:\n{save_path}")
    else:
        messagebox.showerror("Error", "No data to save.")

def download_result_xlsx():
    if result_df is not None:
        save_path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
        if save_path:
            result_df.to_excel(save_path, index=False)
            messagebox.showinfo("Saved", f"Excel file saved to:\n{save_path}")
    else:
        messagebox.showerror("Error", "No data to save.")

def reset_app():
    global result_df
    result_df = None
    entry_api_key.delete(0, tk.END)
    entry_file_path.delete(0, tk.END)
    
    # Clear table (Treeview)
    for item in tree.get_children():
        tree.delete(item)

    stop_spinner()
    messagebox.showinfo("Reset", "App has been reset.")

# ------------------ GUI Setup ------------------

BG_COLOR = "#0f111a"
INPUT_BG = "#1e222f"
TEXT_COLOR = "#e1e1e6"
ACCENT_COLOR = "#4fa7ff"
FONT = ("Segoe UI", 10)
TITLE_FONT = ("Segoe UI", 18, "bold")

root = tk.Tk()
root.title("Phone Number Validator")
root.geometry("860x720")
root.configure(bg=BG_COLOR)

style = ttk.Style()
style.theme_use("clam")
style.configure("TButton", font=FONT, background=INPUT_BG, foreground=TEXT_COLOR, padding=8, borderwidth=0, relief="flat")
style.map("TButton", background=[('active', ACCENT_COLOR)])
style.configure("Treeview",
    background=INPUT_BG,
    foreground=TEXT_COLOR,
    rowheight=25,
    fieldbackground=INPUT_BG,
    font=FONT)

style.map('Treeview', background=[('selected', ACCENT_COLOR)])
style.configure("Treeview.Heading",
    background=BG_COLOR,
    foreground=ACCENT_COLOR,
    font=("Segoe UI", 10, "bold"))

# ------------------ Header ------------------

tk.Label(root, text="Phone Number Validator", font=TITLE_FONT, bg=BG_COLOR, fg=TEXT_COLOR).pack(pady=(30, 10))
tk.Label(root, text="Built with Veriphone API", font=("Segoe UI", 10), bg=BG_COLOR, fg="#888888").pack(pady=(0, 20))

# ------------------ Input Fields ------------------

tk.Label(root, text="Your Veriphone API Key", bg=BG_COLOR, fg=TEXT_COLOR, font=FONT).pack()
entry_api_key = tk.Entry(root, width=70, font=FONT, bg=INPUT_BG, fg=TEXT_COLOR, insertbackground=TEXT_COLOR, bd=0, relief="flat")
entry_api_key.pack(pady=6)

tk.Label(root, text="CSV File Path", bg=BG_COLOR, fg=TEXT_COLOR, font=FONT).pack(pady=(20, 0))
entry_file_path = tk.Entry(root, width=70, font=FONT, bg=INPUT_BG, fg=TEXT_COLOR, insertbackground=TEXT_COLOR, bd=0, relief="flat")
entry_file_path.pack(pady=6)

ttk.Button(root, text="Browse", command=select_file).pack(pady=(0, 20))

# ------------------ Buttons ------------------

btn_frame = tk.Frame(root, bg=BG_COLOR)
btn_frame.pack(pady=10)

ttk.Button(btn_frame, text="Validate Numbers", command=threaded_validate_numbers).pack(side="left", padx=10)
ttk.Button(btn_frame, text="Download CSV", command=download_result).pack(side="left", padx=10)
ttk.Button(btn_frame, text="Download XLSX", command=download_result_xlsx).pack(side="left", padx=10)
ttk.Button(btn_frame, text="Reset", command=reset_app).pack(side="left", padx=10)
ttk.Button(btn_frame, text="Send Email", command=send_email_with_attachment).pack(side="left", padx=10)
ttk.Button(btn_frame, text="Download PDF", command=download_result_pdf).pack(side="left", padx=10)

# ------------------ Spinner ------------------

spinner_frame = tk.Frame(root, bg=BG_COLOR)
progress_spinner = ttk.Progressbar(spinner_frame, mode='indeterminate', length=200)
progress_spinner.pack()
spinner_label = tk.Label(spinner_frame, text="", font=("Segoe UI", 10), bg=BG_COLOR, fg=ACCENT_COLOR)
spinner_label.pack()

# ------------------ Preview Box ------------------

# ------------------ Treeview Table ------------------

columns = ("Phone", "Valid", "Country", "Carrier")

tree = ttk.Treeview(root, columns=columns, show="headings", height=15)
tree.pack(padx=10, pady=(20, 10), fill="both", expand=True)

# Define headings
for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=180, anchor='center')

# ------------------ Footer ------------------

tk.Label(root, text="Designed by Shazia", font=("Segoe UI", 9), bg=BG_COLOR, fg="#5e5e5e").pack(pady=10)

root.mainloop()